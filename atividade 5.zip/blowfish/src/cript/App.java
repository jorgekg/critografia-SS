package cript;
import view.CriptView;

public class App {

	public static void main(String[] args) {
		new CriptView();
	}

}
